package com.salesianostriana.dam.pruebas.servicio;

import com.salesianostriana.dam.pruebas.modelo.Sesion;
import com.salesianostriana.dam.pruebas.repositorio.SesionRepositorio;
import com.salesianostriana.dam.pruebas.servicio.base.ServicioBase;

public class SesionServicio extends ServicioBase<Sesion, Long, SesionRepositorio>{

}
