package com.salesianostriana.dam.pruebas.servicio;

import com.salesianostriana.dam.pruebas.modelo.Agrupacion;
import com.salesianostriana.dam.pruebas.repositorio.AgrupacionRepositorio;
import com.salesianostriana.dam.pruebas.servicio.base.ServicioBase;

public class AgrupacionServicio extends ServicioBase<Agrupacion, Long, AgrupacionRepositorio>{

}
